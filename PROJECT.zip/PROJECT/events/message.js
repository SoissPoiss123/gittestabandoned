module.exports = (client) => {
    client.on("messageCreate", (msg) => {
        // global basic commands can remain here
        if (msg.content === "!ping") msg.reply("Pong!");
    });
};
