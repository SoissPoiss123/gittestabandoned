// Example module showing safeCall usage and per-module config
module.exports = (client, logger, safe, modConfig) => {
    logger('Example module init, config: ' + JSON.stringify(modConfig));

    if (modConfig.enabled === false) {
        logger('Module disabled via config.');
        return;
    }

    // Example: a simple command handler wrapped in safe()
    client.on('messageCreate', safe(async (msg) => {
        if (msg.author.bot) return;
        if (msg.content === '!logtest') {
            logger('!logtest used by ' + msg.author.tag);
            await msg.reply('Log written. Check logs/' + (modConfig.name || 'example') + '.log');
        }

        // This line demonstrates a runtime error that will be caught by safe()
        if (msg.content === '!crashme') {
            throw new Error('Intentional crash from example module');
        }
    }));

    // Example background task that might fail and can be restarted by the module itself
    let intervalId = null;
    const startTask = () => {
        if (intervalId) return;
        intervalId = setInterval(async () => {
            try {
                // simulate periodic action
                logger('Background task tick');
            } catch (err) {
                logger('Background task error: ' + (err.stack || err));
                // notify if configured
                if (modConfig.logToDiscord && modConfig.logChannelId) {
                    try {
                        const ch = await client.channels.fetch(modConfig.logChannelId).catch(()=>null);
                        if (ch && ch.send) ch.send(`⚠️ Module \`${modConfig.name}\` background task error:\n\`\`\`${err.message}\`\`\``).catch(()=>null);
                    } catch(e){}
                }
                // if autorestart enabled, restart the task
                if (modConfig.autorestart) {
                    clearInterval(intervalId);
                    intervalId = null;
                    logger('Restarting background task due to error (autorestart enabled)');
                    startTask();
                }
            }
        }, 10000); // every 10s for demo
        logger('Background task started');
    };

    startTask();

    // cleanup on process exit (optional)
    process.on('exit', () => {
        if (intervalId) clearInterval(intervalId);
    });
};
