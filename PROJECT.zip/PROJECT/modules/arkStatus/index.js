const { EmbedBuilder } = require("discord.js");
const pool = require("../../db");
const { queryServer } = require("./serverQuery");

module.exports = (client, logger, safe, modConfig) => {
    logger("[arkStatus] Module init, config:", modConfig);

    if (!modConfig.enabled) {
        logger("[arkStatus] Module disabled.");
        return;
    }

    const updateStatus = safe(async () => {
        const statusChannel = await client.channels.fetch(modConfig.statusChannelId).catch(() => null);

        if (!statusChannel || typeof statusChannel.send !== "function") {
            logger("[arkStatus] Cannot write to status channel");
            return;
        }

        // Load bot state
        let [rows] = await pool.query("SELECT * FROM bot_state LIMIT 1");
        let row;

        if (!rows.length) {
            await pool.query(
                "INSERT INTO bot_state (message_id, all_time_max, yesterday_max, daily_peak) VALUES (?, ?, ?, ?)",
                [null, 0, 0, 0]
            );
            row = { id: 1, message_id: null, all_time_max: 0, yesterday_max: 0, daily_peak: 0 };
        } else {
            row = rows[0];
        }

        let statuses = [];
        let totalOnline = 0;
        let onlineServers = 0;

        // Query servers
        for (const server of modConfig.servers) {
            const result = await queryServer(server.ip, server.queryPort, server.maxPlayers);

            statuses.push({
                name: server.name,
                displayName: server.displayName || server.name, // Use displayName if available, fallback to name
                online: result.online,
                players: result.players,
                max: result.maxPlayers,
                ip: server.ip,
                port: server.queryPort
            });

            if (result.online) {
                totalOnline += result.players;
                onlineServers++;
            }
        }

        // Peak updates
        if (totalOnline > row.daily_peak) {
            row.daily_peak = totalOnline;
            await pool.query("UPDATE bot_state SET daily_peak = ? WHERE id = ?", [totalOnline, row.id]);
        }

        if (totalOnline > row.all_time_max) {
            row.all_time_max = totalOnline;
            await pool.query("UPDATE bot_state SET all_time_max = ? WHERE id = ?", [totalOnline, row.id]);
        }

        // Build embed
        const embed = new EmbedBuilder()
            .setTitle("🦖 IronNode ARK Server Status BOT")
            .setColor(onlineServers > 0 ? 0x5865F2 : 0xED4245)
            .setTimestamp()
            .setFooter({ text: "IronNode Official BOT • Last update" });

        // Create treeview display for servers
        let serverDisplay = "**\n**";

        for (let i = 0; i < statuses.length; i++) {
            const s = statuses[i];
            const statusIcon = s.online ? "" : "";
            const statusColor = s.online ? "🟩" : "🟥";
            const playerText = s.online ? `**${s.players}**/${s.max} playing` : "Server offline";
            
            // Use displayName for the first line (where the online icon is)
            serverDisplay += `${statusColor} **${s.displayName}** ${statusIcon}\n` +
                            
                           `└─ 🌐 \`${s.ip}:${s.port}\`\n` +
                           `└─ 👥 ${playerText}\n\n`;

            // Add visual separator after every 0 servers
            if ((i + 1) % 0 === 0 && i < statuses.length - 1) {
                serverDisplay += "▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n\n";
            }
        }

// Create statistics display - Treeview with Arrows (with Yesterday's Peak)
const statsDisplay = "\n**📊 CLUSTER STATISTICS**\n" +
                   "```\n" +
                   `┌─ CLUSTER ──────────────────┐\n` +
                   `│  🟢 Servers Online        \n` +
                   `│  └─ ${onlineServers}/${statuses.length}                  │\n\n` +
                   `│  👥 Players Online        \n` +
                   `│  └─ ${totalOnline}                      │\n\n` +
                   `│  📈 Todays Peak           \n` +
                   `│  └─ ${row.daily_peak}                      │\n\n` +
                   `│  📅 Yesterdays Peak       \n` +
                   `│  └─ ${row.yesterday_max}                      │\n\n` +
                   `│  🏆 All Time Peak         \n` +
                   `│  └─ ${row.all_time_max}                      │\n` +
                   `└───────────────── OVERVIEW ─┘\n` +
                   "```";
        // Set the combined content as description
        embed.setDescription(serverDisplay + statsDisplay);

        // Update or create embed
        let msg;

        if (row.message_id) {
            msg = await statusChannel.messages.fetch(row.message_id).catch(() => null);
            if (msg) {
                await msg.edit({ embeds: [embed] });
                return;
            }
        }

        msg = await statusChannel.send({ embeds: [embed] });
        await pool.query("UPDATE bot_state SET message_id = ? WHERE id = ?", [msg.id, row.id]);
    });

    setInterval(updateStatus, (modConfig.updateIntervalSeconds || 60) * 1000);
    updateStatus();
};