const Gamedig = require('gamedig');

async function queryServer(host, port, customMaxPlayers = null) {
  try {
    const state = await Gamedig.query({
      type: 'arkse',
      host,
      port
    });

    const realPlayers = state.players.filter(p => p.name && p.name.trim() !== '');
    const maxPlayers = customMaxPlayers || state.maxplayers;

    return {
      online: true,
      name: state.name || state.map || `Server ${host}:${port}`, // Return the actual map name
      players: realPlayers.length,
      maxPlayers: maxPlayers
    };
  } catch (e) {
    return {
      online: false,
      name: null,
      players: 0,
      maxPlayers: customMaxPlayers || 0
    };
  }
}

module.exports = { queryServer };