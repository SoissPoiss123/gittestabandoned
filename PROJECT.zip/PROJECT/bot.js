require('dotenv').config();
const { Client, GatewayIntentBits } = require('discord.js');
const fs = require('fs');
const path = require('path');

// --------------------------------------------
// CLIENT
// --------------------------------------------
const client = new Client({
    intents: [
        GatewayIntentBits.Guilds,
        GatewayIntentBits.GuildMessages
    ]
});

// --------------------------------------------
// GLOBAL ERROR CATCHERS (IMPORTANT!)
// --------------------------------------------
process.on("unhandledRejection", (reason) => {
    console.error("\n==== UNHANDLED REJECTION ====");
    console.error(reason);
    console.error("================================\n");
});

process.on("uncaughtException", (err) => {
    console.error("\n==== UNCAUGHT EXCEPTION ====");
    console.error(err.stack || err);
    console.error("================================\n");
});

// --------------------------------------------
// LOGGER
// --------------------------------------------
const logger = (...args) => console.log('[BOT]', ...args);

// --------------------------------------------
// SAFE WRAPPER (EXPANDED)
// --------------------------------------------
function safe(fn) {
    return async (...args) => {
        try {
            return await fn(...args);
        } catch (err) {
            console.error("\n========== SAFE WRAPPER ERROR ==========");
            console.error(err.stack || err);
            console.error("=========================================\n");
        }
    };
}

// --------------------------------------------
// READY
// --------------------------------------------
client.once('clientReady', () => {
    logger(`Logged in as ${client.user.tag}`);

    const modulesPath = path.join(__dirname, 'modules');

    fs.readdirSync(modulesPath).forEach(dir => {
        const indexFile = path.join(modulesPath, dir, 'index.js');
        const configFile = path.join(modulesPath, dir, 'config.json');

        if (!fs.existsSync(indexFile)) return;

        try {
            const modConfig = fs.existsSync(configFile)
                ? require(configFile)
                : {};

            logger(`[ModuleLoader] Loading module: ${dir}`);

            const mod = require(indexFile);
            mod(client, logger, safe, modConfig);

        } catch (err) {
            console.error("\n========== MODULE LOAD ERROR ==========");
            console.error(`Module: ${dir}`);
            console.error(err.stack || err);
           	console.error("========================================\n");
        }
    });
});

// --------------------------------------------
// LOGIN
// --------------------------------------------
client.login(process.env.DISCORD_TOKEN);
