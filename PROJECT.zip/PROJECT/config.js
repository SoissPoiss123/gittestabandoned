module.exports = {
    token: "MTQ0MjExOTQxMjcwMTMzNTU5Mg.GzTYQn.qWy6ebKdLrkrVXH340Rco-ABGHhgO17bU1MKB4",
    autoRestart: false,
    maxRestarts: 10,   
    logChannelId: "1443630457081036933"
};