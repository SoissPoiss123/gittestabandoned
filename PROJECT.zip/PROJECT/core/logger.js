const fs = require('fs');
const path = require('path');

module.exports = function(moduleName) {
    const logPath = path.join(__dirname, '../logs');
    if (!fs.existsSync(logPath)) fs.mkdirSync(logPath, { recursive: true });

    const file = path.join(logPath, `${moduleName}.log`);

    return function log(message) {
        const timestamp = new Date().toISOString();
        const line = `[${timestamp}] ${message}\n`;
        fs.appendFile(file, line, err => {
            if (err) console.error(`Failed writing ${moduleName} log:`, err);
        });

        console.log(`[${moduleName}]`, message);
    };
};
