const fs = require('fs');
const path = require('path');
const createLogger = require('./logger');
const SafeCallFactory = require('./safeCall');

module.exports = (client) => {
    const modulesPath = path.join(__dirname, '../modules');
    if (!fs.existsSync(modulesPath)) return;

    const folders = fs.readdirSync(modulesPath, { withFileTypes: true })
        .filter(d => d.isDirectory())
        .map(d => d.name);

    folders.forEach(folder => {
        const modulePath = path.join(modulesPath, folder, 'index.js');
        const configPath = path.join(modulesPath, folder, 'config.json');
        let modConfig = {};
        if (fs.existsSync(configPath)) {
            try {
                modConfig = JSON.parse(fs.readFileSync(configPath, 'utf8'));
            } catch (e) {
                console.error(`[ModuleLoader] Failed reading config for ${folder}:`, e);
            }
        }
        // inject name into modConfig for convenient logging
        modConfig.name = folder;

        if (fs.existsSync(modulePath)) {
            const logger = createLogger(folder);
            const safe = SafeCallFactory(logger, modConfig, client);

            try {
                const modFn = require(modulePath);
                // pass (client, logger, safe, modConfig)
                modFn(client, logger, safe, modConfig);
                logger('Module loaded successfully');
            } catch (e) {
                console.error(`[ModuleLoader] Failed to load module ${folder}:`, e);
                // write to module log as well
                logger(`Failed to load module: ${e.stack || e}`);
            }
        }
    });
};
