const { logChannelId } = require('../config');

function sendToLogChannel(client, text) {
    if (!logChannelId) return Promise.resolve();
    // try fetch to ensure uncached channels are reached
    return client.channels.fetch(logChannelId).then(ch => {
        if (ch && ch.send) return ch.send(text).catch(()=>null);
    }).catch(()=>null);
}

module.exports = (client) => {
    process.on('uncaughtException', async (err) => {
        console.error('Uncaught Exception:', err);
        await sendToLogChannel(client, `❗ Bot uncaught exception:\n\`\`\`${err && err.stack ? err.stack : String(err)}\`\`\``);
        // Do NOT auto-restart the whole process here. Let operator decide.
        // Exit with non-zero code is optional; we keep process alive to allow module isolation.
    });

    process.on('unhandledRejection', async (reason, p) => {
        console.error('Unhandled Rejection at:', p, 'reason:', reason);
        await sendToLogChannel(client, `❗ Unhandled Promise Rejection:\n\`\`\`${reason && reason.stack ? reason.stack : String(reason)}\`\`\``);
    });
};
