// safeCall returns a wrapper that catches errors inside a module's event handler
module.exports = function(logger, modConfig, client) {
    return function(fn, opts = {}) {
        return async function(...args) {
            try {
                await fn(...args);
            } catch (err) {
                const errMsg = err && err.stack ? err.stack : String(err);
                logger(`Module runtime error: ${errMsg}`);
                // Optionally send to Discord if module config asks so
                try {
                    if (modConfig && modConfig.logToDiscord && modConfig.logChannelId) {
                        const chan = await client.channels.fetch(modConfig.logChannelId).catch(()=>null);
                        if (chan && chan.send) {
                            chan.send(`⚠️ Module \`${modConfig.name || 'unknown'}\` error:\n\`\`\` ${err.message || err} \`\`\``).catch(()=>null);
                        }
                    }
                } catch(e) {
                    // ignore
                }
            }
        };
    };
};
